# Food2Farm Website

A browser front end (HTML, CSS, vanilla JS) for the original C++ Food2Farm project.
The C++ server (`backend/main.cpp`) keeps one `Food2Farm` object. Every action runs the
original code: queues, matching scores, Dijkstra and completion rules.

## Setup (Windows)
1. Copy your **unchanged** `Food2Farm.cpp` into the `backend` folder. It stays your terminal version too.
2. Install a C++17 compiler (MinGW-w64 g++) and make sure `g++` works in Command Prompt.
3. Double-click `start.bat`. It downloads `httplib.h` and `json.hpp` (needs internet once), compiles and starts the server.
4. The browser opens at http://localhost:8080

Manual build, from the `backend` folder:

    g++ -std=c++17 -O2 -D_WIN32_WINNT=0x0A00 main.cpp -o Food2Farm.exe -lws2_32 -lwsock32

## How it works
`main.cpp` includes `Food2Farm.cpp` with `#define private public` and renames its `main`.
For each API call it feeds the original function's `cin` from a string and captures its `cout`,
so the algorithms are reused rather than copied. Web-form input is validated first.

## Limitation
All records are in memory only. Restarting the server resets everything.

## Demo flow
Add provider, add farmer, create request, Process next request, view matches, Assign & complete,
check History and Dashboard, try Routes.
