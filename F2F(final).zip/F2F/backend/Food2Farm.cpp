#include <iostream>
#include <queue>
#include <unordered_map>
#include <algorithm>
#include <string>
#include <limits>
#include <iomanip>
#include <cmath>
#include <initializer_list>

#include <vector>
#include <functional>
#include <utility>
#include <cctype>

using namespace std;

// Small custom dynamic array used for project record lists instead of std::vector.
template <typename T>
class DynamicArray {
    T* data_;
    size_t size_;
    size_t capacity_;
    void grow() {
        size_t cap = capacity_ == 0 ? 4 : capacity_ * 2;
        T* next = new T[cap];
        for (size_t i = 0; i < size_; ++i) next[i] = data_[i];
        delete[] data_;
        data_ = next;
        capacity_ = cap;
    }
public:
    DynamicArray() : data_(nullptr), size_(0), capacity_(0) {}
    DynamicArray(std::initializer_list<T> items) : DynamicArray() {
        for (const T& item : items) push_back(item);
    }
    DynamicArray(const DynamicArray& other) : DynamicArray() {
        for (const T& item : other) push_back(item);
    }
    DynamicArray& operator=(const DynamicArray& other) {
        if (this != &other) {
            delete[] data_; data_ = nullptr; size_ = 0; capacity_ = 0;
            for (const T& item : other) push_back(item);
        }
        return *this;
    }
    ~DynamicArray() { delete[] data_; }
    void push_back(const T& value) {
        if (size_ == capacity_) grow();
        data_[size_++] = value;
    }
    void pop_back() { if (size_ > 0) --size_; }
    size_t size() const { return size_; }
    bool empty() const { return size_ == 0; }
    T& operator[](size_t i) { return data_[i]; }
    const T& operator[](size_t i) const { return data_[i]; }
    T* begin() { return data_; }
    T* end() { return data_ + size_; }
    const T* begin() const { return data_; }
    const T* end() const { return data_ + size_; }
};

/*
    FOOD2FARM - CORE / APPROXIMATELY 40% VERSION (CUSTOM DYNAMIC ARRAY)
    Terminal-based C++17 mini project using OOP and DSA.

    Suggested student-wise explanation:
    1. Mohit Singh     : main menu and program integration
    2. Kushagra Negi   : structures, vectors, hash maps / records
    3. Navdeep Singh   : normal queue and urgent priority queue
    4. Niharika Joshi  : eligible farmer matching and scoring
    5. Arpit Panwar    : graph and Dijkstra shortest route
    6. Manpreet Singh  : collection history and summary report

    This is a core version, not the complete project. Record lists use a custom DynamicArray; the standard priority_queue adaptor retains its required backing container. The locations and
    distances are demonstration data, not live road/navigation data.
*/

// -------------------- Kushagra Negi: DATA MODELS --------------------
struct Provider {
    int id{};
    string name;
    string location;
};

struct Farmer {
    int id{};
    string name;
    string location;
    double capacityKg{};
    bool available{true};
    DynamicArray<string> categories;
};

struct WasteRequest {
    int id{};
    int providerId{};
    string category;
    string pickupLocation;
    double quantityKg{};
    int urgency{1};       // 1 = normal, 2 = medium, 3 = urgent
    string status{"Pending"};
};

struct Collection {
    int id{};
    int requestId{};
    int farmerId{};
    double distanceKm{};
    string route;
    string status{"Completed"};
};

struct PriorityItem {
    int urgency;
    int requestId;
    // priority_queue puts the largest urgency first.
    bool operator<(const PriorityItem& other) const {
        if (urgency != other.urgency) return urgency < other.urgency;
        return requestId > other.requestId;
    }
};

class Food2Farm {
private:
    // -------------------- Kushagra Negi: DATA STORAGE --------------------
    DynamicArray<Provider> providers;
    DynamicArray<Farmer> farmers;
    DynamicArray<WasteRequest> requests;
    DynamicArray<Collection> history;

    // Hash maps store the index of each record using its ID as key.
    unordered_map<int, size_t> providerIndex;
    unordered_map<int, size_t> farmerIndex;
    unordered_map<int, size_t> requestIndex;

    int nextProviderId = 1;
    int nextFarmerId = 1;
    int nextRequestId = 1;
    int nextCollectionId = 1;

    // -------------------- Navdeep: REQUEST QUEUES --------------------
    queue<int> normalQueue;
    priority_queue<PriorityItem> urgentQueue;

    // -------------------- Arpit: WEIGHTED GRAPH --------------------
    // Each location maps to its neighbouring locations and distances.
    unordered_map<string, DynamicArray<pair<string, double>>> graph;

    static string lowerCase(string s) {
        transform(s.begin(), s.end(), s.begin(),
                  [](unsigned char c) { return static_cast<char>(tolower(c)); });
        return s;
    }

    bool categoryMatches(const Farmer& f, const string& category) const {
        if (f.categories.empty()) return true;
        for (const string& c : f.categories) {
            if (lowerCase(c) == "all" || lowerCase(c) == lowerCase(category))
                return true;
        }
        return false;
    }

    void addRoad(const string& a, const string& b, double km) {
        graph[a].push_back({b, km});
        graph[b].push_back({a, km});
    }

    void initializeRoads() {
        // Demo distances only. These can be replaced with verified project data.
        addRoad("Dehradun", "Premnagar", 8);
        addRoad("Dehradun", "Rajpur", 7);
        addRoad("Premnagar", "Clement Town", 10);
        addRoad("Rajpur", "Clement Town", 12);
        addRoad("Clement Town", "ISBT", 6);
        addRoad("Premnagar", "ISBT", 9);
    }

    // -------------------- Arpit: DIJKSTRA ALGORITHM --------------------
    bool shortestRoute(const string& source, const string& destination,
                       double& distance, DynamicArray<string>& path) const {
        if (!graph.count(source) || !graph.count(destination)) return false;

        unordered_map<string, double> dist;
        unordered_map<string, string> previous;
        for (const auto& node : graph)
            dist[node.first] = numeric_limits<double>::infinity();

        using State = pair<double, string>;
        priority_queue<State, std::vector<State>, greater<State>> pq;
        dist[source] = 0;
        pq.push({0, source});

        while (!pq.empty()) {
            auto current = pq.top();
            pq.pop();
            double d = current.first;
            string u = current.second;
            if (d > dist[u]) continue;
            if (u == destination) break;

            auto it = graph.find(u);
            if (it == graph.end()) continue;
            for (const auto& edge : it->second) {
                const string& v = edge.first;
                double weight = edge.second;
                if (d + weight < dist[v]) {
                    dist[v] = d + weight;
                    previous[v] = u;
                    pq.push({dist[v], v});
                }
            }
        }

        if (!isfinite(dist[destination])) return false;
        distance = dist[destination];
        DynamicArray<string> reversePath;
        string node = destination;
        reversePath.push_back(node);
        while (node != source) {
            auto it = previous.find(node);
            if (it == previous.end()) return false;
            node = it->second;
            reversePath.push_back(node);
        }
        reverse(reversePath.begin(), reversePath.end());
        path = reversePath;
        return true;
    }

    // -------------------- Navdeep: ENQUEUE A REQUEST --------------------
    void enqueueRequest(const WasteRequest& r) {
        if (r.urgency >= 3 || r.quantityKg >= 50)
            urgentQueue.push({r.urgency, r.id});
        else
            normalQueue.push(r.id);
    }

    int findNextRequestId() {
        // Discard stale IDs (e.g. requests already completed or cancelled).
        while (!urgentQueue.empty()) {
            int id = urgentQueue.top().requestId;
            urgentQueue.pop();
            auto it = requestIndex.find(id);
            if (it != requestIndex.end() && requests[it->second].status == "Pending")
                return id;
        }
        while (!normalQueue.empty()) {
            int id = normalQueue.front();
            normalQueue.pop();
            auto it = requestIndex.find(id);
            if (it != requestIndex.end() && requests[it->second].status == "Pending")
                return id;
        }
        return -1;
    }

public:
    Food2Farm() { initializeRoads(); }

    // -------------------- Kushagra Negi: PROVIDER CRUD --------------------
    void addProvider() {
        Provider p;
        p.id = nextProviderId++;
        cout << "Provider/restaurant name: ";
        getline(cin >> ws, p.name);
        cout << "Location (Dehradun/Premnagar/Rajpur/Clement Town/ISBT): ";
        getline(cin, p.location);
        providers.push_back(p);
        providerIndex[p.id] = providers.size() - 1;
        cout << "Provider registered. ID = " << p.id << "\n";
    }

    // -------------------- Kushagra Negi: FARMER CRUD --------------------
    void addFarmer() {
        Farmer f;
        f.id = nextFarmerId++;
        cout << "Farmer name: ";
        getline(cin >> ws, f.name);
        cout << "Location (Dehradun/Premnagar/Rajpur/Clement Town/ISBT): ";
        getline(cin, f.location);
        cout << "Available capacity in kg: ";
        if (!(cin >> f.capacityKg) || f.capacityKg <= 0) {
            cout << "Invalid capacity. Farmer not registered.\n";
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
            --nextFarmerId;
            return;
        }
        int availableInput;
        cout << "Available now? (1=yes, 0=no): ";
        if (!(cin >> availableInput)) {
            cout << "Invalid input. Farmer not registered.\n";
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
            --nextFarmerId;
            return;
        }
        f.available = (availableInput == 1);
        cout << "Waste category (e.g. Vegetable, Fruit, All): ";
        string category;
        getline(cin >> ws, category);
        f.categories.push_back(category);
        farmers.push_back(f);
        farmerIndex[f.id] = farmers.size() - 1;
        cout << "Farmer registered. ID = " << f.id << "\n";
    }

    // -------------------- Kushagra Negi: CREATE WASTE REQUEST --------------------
    void createRequest() {
        if (providers.empty()) {
            cout << "Register a provider first.\n";
            return;
        }
        cout << "Registered providers:\n";
        for (const Provider& p : providers)
            cout << "ID " << p.id << " - " << p.name << " (" << p.location << ")\n";

        WasteRequest r;
        r.id = nextRequestId++;
        cout << "Provider ID: ";
        if (!(cin >> r.providerId) || !providerIndex.count(r.providerId)) {
            cout << "Invalid provider ID.\n";
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
            --nextRequestId;
            return;
        }
        cout << "Waste category: ";
        getline(cin >> ws, r.category);
        cout << "Pickup location: ";
        getline(cin, r.pickupLocation);
        cout << "Quantity (kg): ";
        if (!(cin >> r.quantityKg) || r.quantityKg <= 0) {
            cout << "Quantity must be positive.\n";
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
            --nextRequestId;
            return;
        }
        cout << "Urgency (1=normal, 2=medium, 3=urgent): ";
        if (!(cin >> r.urgency) || r.urgency < 1 || r.urgency > 3) {
            cout << "Urgency must be 1, 2 or 3.\n";
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
            --nextRequestId;
            return;
        }
        r.status = "Pending";
        requests.push_back(r);
        requestIndex[r.id] = requests.size() - 1;
        enqueueRequest(r);
        cout << "Waste request created. Request ID = " << r.id << "\n";
    }

    // -------------------- Kushagra Negi: DISPLAY RECORDS --------------------
    void listProviders() const {
        cout << "\n--- PROVIDERS ---\n";
        if (providers.empty()) cout << "No providers registered.\n";
        for (const Provider& p : providers)
            cout << "ID: " << p.id << " | " << p.name << " | " << p.location << "\n";
    }

    void listFarmers() const {
        cout << "\n--- FARMERS ---\n";
        if (farmers.empty()) cout << "No farmers registered.\n";
        for (const Farmer& f : farmers)
            cout << "ID: " << f.id << " | " << f.name << " | " << f.location
                 << " | Capacity: " << f.capacityKg << " kg | Available: "
                 << (f.available ? "Yes" : "No") << "\n";
    }

    void listRequests() const {
        cout << "\n--- WASTE REQUESTS ---\n";
        if (requests.empty()) cout << "No requests created.\n";
        for (const WasteRequest& r : requests)
            cout << "ID: " << r.id << " | Provider ID: " << r.providerId
                 << " | " << r.category << " | " << r.quantityKg << " kg | Urgency: "
                 << r.urgency << " | Status: " << r.status << "\n";
    }

    // --------------------Niharika joshi: FARMER MATCHING --------------------
    void findMatches() const {
        int id;
        cout << "Request ID to match: ";
        if (!(cin >> id) || !requestIndex.count(id)) {
            cout << "Invalid request ID.\n";
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return;
        }
        const WasteRequest& r = requests[requestIndex.at(id)];
        DynamicArray<pair<double, int>> ranked; // score, farmer ID

        for (const Farmer& f : farmers) {
            if (!f.available || f.capacityKg < r.quantityKg) continue;
            if (!categoryMatches(f, r.category)) continue;

            // Demo score: capacity fit 40%, location fit 35%, availability 25%.
            double capacityScore = min(1.0, r.quantityKg / f.capacityKg);
            double locationScore = lowerCase(f.location) == lowerCase(r.pickupLocation) ? 1.0 : 0.5;
            double availabilityScore = f.available ? 1.0 : 0.0;
            double score = (0.40 * capacityScore + 0.35 * locationScore
                            + 0.25 * availabilityScore) * 100.0;
            ranked.push_back({score, f.id});
        }
        sort(ranked.begin(), ranked.end(), greater<pair<double, int>>());
        cout << "\nEligible farmers ranked by demo score:\n";
        if (ranked.empty()) cout << "No eligible farmer found.\n";
        for (const auto& item : ranked) {
            const Farmer& f = farmers[farmerIndex.at(item.second)];
            cout << fixed << setprecision(1) << "Score " << item.first << "% | ID "
                 << f.id << " | " << f.name << " | " << f.location
                 << " | Capacity " << f.capacityKg << " kg\n";
        }
    }

    // --------------------Navdeep: PROCESS NEXT REQUEST --------------------
    void processNextRequest() {
        int id = findNextRequestId();
        if (id == -1) {
            cout << "No pending requests in the queues.\n";
            return;
        }
        WasteRequest& r = requests[requestIndex.at(id)];
        r.status = "Assigned";
        cout << "Request " << id << " selected for processing.\n";
        cout << "Category: " << r.category << " | Quantity: " << r.quantityKg
             << " kg | Urgency: " << r.urgency << "\n";
        cout << "Use 'Find farmer matches' to view suitable farmers.\n";
    }

    // -------------------- Arpit: ROUTE DISPLAY --------------------
    void findRoute() const {
        string source, destination;
        cout << "Source location: ";
        getline(cin >> ws, source);
        cout << "Destination location: ";
        getline(cin, destination);
        double distance = 0;
        DynamicArray<string> path;
        if (!shortestRoute(source, destination, distance, path)) {
            cout << "Route not found. Use one of the demo locations exactly.\n";
            return;
        }
        cout << "Shortest demo route: ";
        for (size_t i = 0; i < path.size(); ++i) {
            if (i) cout << " -> ";
            cout << path[i];
        }
        cout << "\nTotal distance: " << distance << " km\n";
    }

    // --------------------Manpreet: COMPLETE / REPORT --------------------
    void completeRequest() {
        int requestId, farmerId;
        cout << "Request ID to complete: ";
        if (!(cin >> requestId) || !requestIndex.count(requestId)) {
            cout << "Invalid request ID.\n";
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return;
        }
        WasteRequest& r = requests[requestIndex.at(requestId)];
        if (r.status == "Completed" || r.status == "Cancelled") {
            cout << "This request is already closed.\n";
            return;
        }
        cout << "Farmer ID: ";
        if (!(cin >> farmerId) || !farmerIndex.count(farmerId)) {
            cout << "Invalid farmer ID.\n";
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return;
        }
        Farmer& f = farmers[farmerIndex.at(farmerId)];
        if (!f.available || f.capacityKg < r.quantityKg || !categoryMatches(f, r.category)) {
            cout << "Farmer is unavailable, lacks capacity, or category does not match.\n";
            return;
        }
        double distance = 0;
        DynamicArray<string> path;
        if (!shortestRoute(r.pickupLocation, f.location, distance, path)) {
            cout << "No route found between request pickup and farmer location.\n";
            return;
        }
        string route;
        for (size_t i = 0; i < path.size(); ++i) {
            if (i) route += " -> ";
            route += path[i];
        }
        history.push_back({nextCollectionId++, r.id, f.id, distance, route, "Completed"});
        r.status = "Completed";
        f.capacityKg -= r.quantityKg;
        if (f.capacityKg <= 0) f.available = false;
        cout << "Collection completed. Route: " << route << " (" << distance << " km)\n";
    }

    void cancelRequest() {
        int id;
        cout << "Request ID to cancel: ";
        if (!(cin >> id) || !requestIndex.count(id)) {
            cout << "Invalid request ID.\n";
            cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return;
        }
        WasteRequest& r = requests[requestIndex.at(id)];
        if (r.status == "Completed") {
            cout << "Completed request cannot be cancelled.\n";
            return;
        }
        r.status = "Cancelled";
        cout << "Request cancelled.\n";
    }

    void showReport() const {
        int pending = 0, assigned = 0, completed = 0, cancelled = 0;
        double totalKg = 0;
        for (const WasteRequest& r : requests) {
            if (r.status == "Pending") ++pending;
            else if (r.status == "Assigned") ++assigned;
            else if (r.status == "Completed") { ++completed; totalKg += r.quantityKg; }
            else if (r.status == "Cancelled") ++cancelled;
        }
        cout << "\n========== FOOD2FARM REPORT ==========\n";
        cout << "Providers registered : " << providers.size() << "\n";
        cout << "Farmers registered   : " << farmers.size() << "\n";
        cout << "Total requests       : " << requests.size() << "\n";
        cout << "Pending              : " << pending << "\n";
        cout << "Assigned             : " << assigned << "\n";
        cout << "Completed            : " << completed << "\n";
        cout << "Cancelled            : " << cancelled << "\n";
        cout << "Waste collected      : " << totalKg << " kg\n";
        cout << "======================================\n";
    }

    void showHistory() const {
        cout << "\n--- COLLECTION HISTORY ---\n";
        if (history.empty()) cout << "No completed collections yet.\n";
        for (const Collection& c : history) {
            cout << "Collection " << c.id << " | Request " << c.requestId
                 << " | Farmer " << c.farmerId << " | " << c.distanceKm
                 << " km | " << c.route << " | " << c.status << "\n";
        }
    }

    // --------------------Mohit: MENU / INTEGRATION --------------------
    void run() {
        int choice;
        do {
            cout << "\n========== FOOD2FARM (CORE VERSION) ==========\n";
            cout << "1. Register provider\n";
            cout << "2. Register farmer\n";
            cout << "3. Create waste request\n";
            cout << "4. View providers\n";
            cout << "5. View farmers\n";
            cout << "6. View requests\n";
            cout << "7. Find suitable farmer matches\n";
            cout << "8. Process next queued request\n";
            cout << "9. Complete collection\n";
            cout << "10. Cancel request\n";
            cout << "11. Find shortest route\n";
            cout << "12. View collection history\n";
            cout << "13. Show summary report\n";
            cout << "0. Exit\n";
            cout << "Enter choice: ";
            if (!(cin >> choice)) {
                cout << "Please enter a number.\n";
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                continue;
            }
            switch (choice) {
                case 1: addProvider(); break;
                case 2: addFarmer(); break;
                case 3: createRequest(); break;
                case 4: listProviders(); break;
                case 5: listFarmers(); break;
                case 6: listRequests(); break;
                case 7: findMatches(); break;
                case 8: processNextRequest(); break;
                case 9: completeRequest(); break;
                case 10: cancelRequest(); break;
                case 11: findRoute(); break;
                case 12: showHistory(); break;
                case 13: showReport(); break;
                case 0: cout << "Thank you for using Food2Farm!\n"; break;
                default: cout << "Invalid choice. Try again.\n";
            }
        } while (choice != 0);
    }
};

int main() {
    Food2Farm app;
    app.run();
    return 0;
}
