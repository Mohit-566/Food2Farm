// HTTP server for Food2Farm. Food2Farm.cpp (your original file) is included UNCHANGED:
// every operation still runs through the original class, queues, matching and Dijkstra.
#include <iostream>
#include <queue>
#include <unordered_map>
#include <algorithm>
#include <string>
#include <limits>
#include <iomanip>
#include <cmath>
#include <initializer_list>
#include <vector>
#include <functional>
#include <utility>
#include <cctype>
#include <sstream>
#include <fstream>
#include <mutex>
#include <set>
#include "httplib.h"
#include "json.hpp"

#define private public      // lets the server read the class's records and call Dijkstra directly
#define main terminal_main  // keeps the original terminal main() from clashing with ours
#include "Food2Farm.cpp"
#undef main
#undef private

using json = nlohmann::json;
static Food2Farm app;
static mutex mtx;
static const set<string> CATEGORIES = {"vegetable", "fruit", "grain", "dairy", "bakery", "other"};

// Runs an original terminal function: feeds it `input` instead of the keyboard
// and captures what it would have printed.
static string run(const string& input, function<void()> fn) {
    istringstream in(input);
    ostringstream out;
    cin.clear();
    auto oldIn = cin.rdbuf(in.rdbuf());
    auto oldOut = cout.rdbuf(out.rdbuf());
    fn();
    cin.rdbuf(oldIn);
    cout.rdbuf(oldOut);
    cin.clear();
    return out.str();
}

static void reply(httplib::Response& res, int code, const json& j) {
    res.status = code;
    res.set_content(j.dump(), "application/json");
}
static void fail(httplib::Response& res, const string& msg, int code = 400) { reply(res, code, {{"error", msg}}); }

static string trim(string s) {
    s.erase(0, s.find_first_not_of(" \t\r\n"));
    s.erase(s.find_last_not_of(" \t\r\n") + 1);
    return s;
}
static bool validLocation(const string& s) { return app.graph.count(s) > 0; }

static json providerJson(const Provider& p) { return {{"id", p.id}, {"name", p.name}, {"location", p.location}}; }
static json farmerJson(const Farmer& f) {
    return {{"id", f.id}, {"name", f.name}, {"location", f.location}, {"capacityKg", f.capacityKg},
            {"available", f.available}, {"category", f.categories.empty() ? "All" : f.categories[0]}};
}
static json requestJson(const WasteRequest& r) {
    return {{"id", r.id}, {"providerId", r.providerId}, {"category", r.category}, {"pickupLocation", r.pickupLocation},
            {"quantityKg", r.quantityKg}, {"urgency", r.urgency}, {"status", r.status}};
}

int main() {
    httplib::Server svr;
    // Find the frontend folder (works from backend\ or from the project root).
    bool mounted = svr.set_mount_point("/", "../frontend") || svr.set_mount_point("/", "frontend") ||
                   svr.set_mount_point("/", "./");
    if (!mounted) cout << "WARNING: frontend folder not found. Keep 'frontend' next to 'backend'.\n";
    svr.Get("/", [](const httplib::Request&, httplib::Response& res) {
        ifstream f("../frontend/index.html");
        if (!f) f.open("frontend/index.html");
        if (!f) return fail(res, "index.html not found. Put the 'frontend' folder next to 'backend'.", 404);
        stringstream ss;
        ss << f.rdbuf();
        res.set_content(ss.str(), "text/html");
    });

    // Everything the dashboard and tables need, in one call.
    svr.Get("/api/state", [](const httplib::Request&, httplib::Response& res) {
        lock_guard<mutex> lock(mtx);
        json s = {{"providers", json::array()}, {"farmers", json::array()}, {"requests", json::array()},
                  {"collections", json::array()}, {"locations", json::array()}};
        int pending = 0;
        for (const auto& p : app.providers) s["providers"].push_back(providerJson(p));
        for (const auto& f : app.farmers) s["farmers"].push_back(farmerJson(f));
        for (const auto& r : app.requests) {
            s["requests"].push_back(requestJson(r));
            if (r.status == "Pending") ++pending;
        }
        for (const auto& c : app.history)
            s["collections"].push_back({{"id", c.id}, {"requestId", c.requestId}, {"farmerId", c.farmerId},
                                        {"distanceKm", c.distanceKm}, {"route", c.route}, {"status", c.status}});
        for (const auto& n : app.graph) s["locations"].push_back(n.first);
        sort(s["locations"].begin(), s["locations"].end());
        s["stats"] = {{"providers", app.providers.size()}, {"farmers", app.farmers.size()},
                      {"requests", app.requests.size()}, {"pending", pending},
                      {"completed", app.history.size()}};
        reply(res, 200, s);
    });

    svr.Post("/api/providers", [](const httplib::Request& req, httplib::Response& res) {
        lock_guard<mutex> lock(mtx);
        json j = json::parse(req.body, nullptr, false);
        if (j.is_discarded()) return fail(res, "Invalid JSON");
        string name = trim(j.value("name", "")), loc = j.value("location", "");
        if (name.empty()) return fail(res, "Provider name cannot be empty.");
        if (!validLocation(loc)) return fail(res, "Choose a valid location.");
        run(name + "\n" + loc + "\n", [] { app.addProvider(); });
        reply(res, 200, providerJson(app.providers[app.providers.size() - 1]));
    });

    svr.Post("/api/farmers", [](const httplib::Request& req, httplib::Response& res) {
        lock_guard<mutex> lock(mtx);
        json j = json::parse(req.body, nullptr, false);
        if (j.is_discarded()) return fail(res, "Invalid JSON");
        string name = trim(j.value("name", "")), loc = j.value("location", ""), cat = j.value("category", "");
        double cap = j.value("capacityKg", 0.0);
        if (name.empty()) return fail(res, "Farmer name cannot be empty.");
        if (!validLocation(loc)) return fail(res, "Choose a valid location.");
        if (cap <= 0) return fail(res, "Capacity must be positive.");
        if (!CATEGORIES.count(Food2Farm::lowerCase(cat)) && Food2Farm::lowerCase(cat) != "all")
            return fail(res, "Invalid waste category.");
        size_t before = app.farmers.size();
        run(name + "\n" + loc + "\n" + to_string(cap) + "\n" + to_string(j.value("available", 1)) + "\n" + cat + "\n",
            [] { app.addFarmer(); });
        if (app.farmers.size() == before) return fail(res, "Farmer could not be registered.");
        reply(res, 200, farmerJson(app.farmers[app.farmers.size() - 1]));
    });

    svr.Post("/api/requests", [](const httplib::Request& req, httplib::Response& res) {
        lock_guard<mutex> lock(mtx);
        json j = json::parse(req.body, nullptr, false);
        if (j.is_discarded()) return fail(res, "Invalid JSON");
        int pid = j.value("providerId", 0), urgency = j.value("urgency", 0);
        string cat = j.value("category", ""), loc = j.value("pickupLocation", "");
        double qty = j.value("quantityKg", 0.0);
        if (!app.providerIndex.count(pid)) return fail(res, "Provider ID does not exist.");
        if (!CATEGORIES.count(Food2Farm::lowerCase(cat))) return fail(res, "Invalid waste category.");
        if (qty <= 0) return fail(res, "Quantity must be positive.");
        if (!validLocation(loc)) return fail(res, "Choose a valid pickup location.");
        if (urgency < 1 || urgency > 3) return fail(res, "Urgency must be 1, 2 or 3.");
        size_t before = app.requests.size();
        run(to_string(pid) + "\n" + cat + "\n" + loc + "\n" + to_string(qty) + "\n" + to_string(urgency) + "\n",
            [] { app.createRequest(); });
        if (app.requests.size() == before) return fail(res, "Request could not be created.");
        reply(res, 200, requestJson(app.requests[app.requests.size() - 1]));
    });

    // Uses the original urgent priority queue first, then the normal FIFO queue.
    svr.Post("/api/requests/process", [](const httplib::Request&, httplib::Response& res) {
        lock_guard<mutex> lock(mtx);
        int id = app.findNextRequestId();
        if (id == -1) return fail(res, "No pending requests in the queues.", 404);
        WasteRequest& r = app.requests[app.requestIndex.at(id)];
        r.status = "Assigned";
        reply(res, 200, requestJson(r));
    });

    // Runs the original findMatches() and converts its printed lines to JSON.
    svr.Get(R"(/api/requests/(\d+)/matches)", [](const httplib::Request& req, httplib::Response& res) {
        lock_guard<mutex> lock(mtx);
        string out = run(req.matches[1].str() + "\n", [] { app.findMatches(); });
        if (out.find("Invalid") != string::npos) return fail(res, "Request ID does not exist.", 404);
        json list = json::array();
        istringstream lines(out);
        string line;
        while (getline(lines, line)) {
            if (line.rfind("Score ", 0) != 0) continue;
            vector<string> p;
            size_t pos;
            while ((pos = line.find(" | ")) != string::npos) { p.push_back(line.substr(0, pos)); line.erase(0, pos + 3); }
            p.push_back(line);
            if (p.size() < 5) continue;
            list.push_back({{"score", stod(p[0].substr(6))}, {"farmerId", stoi(p[1].substr(3))}, {"name", p[2]},
                            {"location", p[3]}, {"capacity", p[4].substr(9)}});
        }
        reply(res, 200, list);
    });

    // Original Dijkstra.
    svr.Post("/api/routes/shortest", [](const httplib::Request& req, httplib::Response& res) {
        lock_guard<mutex> lock(mtx);
        json j = json::parse(req.body, nullptr, false);
        if (j.is_discarded()) return fail(res, "Invalid JSON");
        string src = j.value("source", ""), dst = j.value("destination", "");
        double dist = 0;
        DynamicArray<string> path;
        if (!app.shortestRoute(src, dst, dist, path)) return fail(res, "Route not found.", 404);
        json p = json::array();
        for (const auto& n : path) p.push_back(n);
        reply(res, 200, {{"source", src}, {"destination", dst}, {"path", p}, {"distanceKm", dist}});
    });

    // Original completeRequest(): checks capacity, availability, category, route and duplicates.
    svr.Post("/api/collections", [](const httplib::Request& req, httplib::Response& res) {
        lock_guard<mutex> lock(mtx);
        json j = json::parse(req.body, nullptr, false);
        if (j.is_discarded()) return fail(res, "Invalid JSON");
        string out = run(to_string(j.value("requestId", 0)) + "\n" + to_string(j.value("farmerId", 0)) + "\n",
                         [] { app.completeRequest(); });
        if (out.find("Collection completed") == string::npos) return fail(res, trim(out));
        reply(res, 200, {{"message", trim(out)}});
    });

    cout << "Food2Farm running at http://localhost:8080  (data resets when this window closes)\n";
    svr.listen("0.0.0.0", 8080);
}
