const $ = s => document.querySelector(s);
const esc = v => String(v).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const CATS = ['Vegetable', 'Fruit', 'Grain', 'Dairy', 'Bakery', 'Other'];
const URG = {1: 'Normal', 2: 'Medium', 3: 'Urgent'};
const NUM = ['capacityKg', 'quantityKg', 'urgency', 'providerId', 'available'];
let S = {providers: [], farmers: [], requests: [], collections: [], locations: [], stats: {}};

function toast(msg, isErr) {
  const t = $('#toast');
  t.textContent = msg; t.className = isErr ? 'err' : ''; t.hidden = false;
  clearTimeout(toast.id); toast.id = setTimeout(() => t.hidden = true, 3500);
}

async function api(path, method = 'GET', body) {
  $('#loader').hidden = false;
  try {
    const r = await fetch('/api/' + path, {method, headers: {'Content-Type': 'application/json'},
      body: body ? JSON.stringify(body) : undefined});
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Request failed');
    return j;
  } catch (e) {
    toast(e.message === 'Failed to fetch' ? 'Cannot reach the C++ server.' : e.message, true);
    throw e;
  } finally { $('#loader').hidden = true; }
}

function table(head, rows) {
  const q = $('#q').value.toLowerCase();
  rows = rows.filter(r => !q || r.join(' ').toLowerCase().includes(q));
  if (!rows.length) return '<p class="muted">No records.</p>';
  return '<div class="tblwrap"><table><tr>' + head.map(h => `<th>${h}</th>`).join('') + '</tr>' +
    rows.map(r => '<tr>' + r.map(c => `<td>${c}</td>`).join('') + '</tr>').join('') + '</table></div>';
}

function fill(sel, items, keep) {
  document.querySelectorAll(sel).forEach(el => {
    const old = el.value;
    el.innerHTML = items.map(([v, t]) => `<option value="${esc(v)}">${esc(t)}</option>`).join('');
    if (keep && [...el.options].some(o => o.value === old)) el.value = old;
  });
}

function render() {
  const st = S.stats, pName = id => (S.providers.find(p => p.id === id) || {}).name || id;
  const fName = id => (S.farmers.find(f => f.id === id) || {}).name || id;
  const stat = [['Providers', st.providers], ['Farmers', st.farmers], ['Requests', st.requests],
    ['Pending', st.pending], ['Collections', st.completed]];
  $('#stats').innerHTML = stat.map(([k, v]) => `<div class="stat"><b>${v ?? 0}</b>${k}</div>`).join('');
  const act = [...S.collections.map(c => `Collection #${c.id}: request ${c.requestId} by ${esc(fName(c.farmerId))} (${c.distanceKm} km)`).reverse(),
    ...S.requests.map(r => `Request #${r.id} (${r.quantityKg} kg ${esc(r.category)}) is ${r.status}`).reverse()].slice(0, 6);
  $('#activity').innerHTML = act.map(a => `<li>${a}</li>`).join('') || '<li class="muted">Nothing yet. Register a provider to start.</li>';

  $('#providerTable').innerHTML = table(['ID', 'Name', 'Location'], S.providers.map(p => [p.id, esc(p.name), esc(p.location)]));
  $('#farmerTable').innerHTML = table(['ID', 'Name', 'Location', 'Capacity (kg)', 'Category', 'Available'],
    S.farmers.map(f => [f.id, esc(f.name), esc(f.location), f.capacityKg, esc(f.category), f.available ? '✅' : '❌']));
  $('#requestTable').innerHTML = table(['ID', 'Provider', 'Category', 'Qty (kg)', 'Pickup', 'Urgency', 'Status'],
    S.requests.map(r => [r.id, esc(pName(r.providerId)), esc(r.category), r.quantityKg, esc(r.pickupLocation),
      URG[r.urgency], `<span class="badge">${r.status}</span>`]));
  $('#historyTable').innerHTML = table(['ID', 'Request', 'Farmer', 'Route', 'Distance', 'Status'],
    S.collections.map(c => [c.id, c.requestId, esc(fName(c.farmerId)), esc(c.route), c.distanceKm + ' km', c.status]));

  fill('.loc', S.locations.map(l => [l, l]), true);
  fill('.cat', CATS.map(c => [c, c]), true);
  fill('.farmerCat', ['All', ...CATS].map(c => [c, c]), true);
  fill('#providerSelect', S.providers.map(p => [p.id, `${p.id} - ${p.name}`]), true);
  fill('#matchSelect', S.requests.filter(r => r.status !== 'Completed' && r.status !== 'Cancelled')
    .map(r => [r.id, `Request ${r.id} (${r.quantityKg} kg ${r.category}, ${r.status})`]), true);
}

const load = async () => { S = await api('state'); render(); };

document.querySelectorAll('nav button').forEach(b => b.onclick = () => {
  document.querySelectorAll('nav button').forEach(x => x.classList.toggle('active', x === b));
  document.querySelectorAll('.tab').forEach(t => t.hidden = t.id !== b.dataset.tab);
  $('#q').value = '';
  $('#q').hidden = !['providers', 'farmers', 'requests', 'history'].includes(b.dataset.tab);
  render();
});
$('#q').oninput = render;

document.querySelectorAll('form[data-api]').forEach(f => f.onsubmit = async e => {
  e.preventDefault();
  const body = Object.fromEntries(new FormData(f));
  NUM.forEach(k => { if (k in body) body[k] = Number(body[k]); });
  try {
    const r = await api(f.dataset.api, 'POST', body);
    toast(`Saved. ID = ${r.id}`);
    f.reset(); await load();
  } catch (_) {}
});

$('#processBtn').onclick = async () => {
  try {
    const r = await api('requests/process', 'POST', {});
    toast(`Request ${r.id} selected for processing.`);
    await load(); $('#matchSelect').value = r.id; showMatches();
  } catch (_) {}
};

async function showMatches() {
  const id = $('#matchSelect').value;
  if (!id) return toast('No open request to match.', true);
  try {
    const list = await api(`requests/${id}/matches`);
    $('#matchTable').innerHTML = list.length ? table(['Score', 'Farmer', 'Location', 'Capacity', ''],
      list.map(m => [m.score.toFixed(1) + '%', esc(m.name), esc(m.location), esc(m.capacity),
        `<button onclick="complete(${id},${m.farmerId})">Assign &amp; complete</button>`]))
      : '<p class="muted">No eligible farmer found.</p>';
  } catch (_) {}
}
$('#matchBtn').onclick = showMatches;

async function complete(requestId, farmerId) {
  try {
    const r = await api('collections', 'POST', {requestId, farmerId});
    toast(r.message); await load(); showMatches();
  } catch (_) {}
}

$('#routeForm').onsubmit = async e => {
  e.preventDefault();
  try {
    const r = await api('routes/shortest', 'POST', {source: $('#src').value, destination: $('#dst').value});
    $('#routeOut').innerHTML = `<p><b>${esc(r.source)}</b> to <b>${esc(r.destination)}</b></p>
      <div class="chips">${r.path.map(n => `<span class="chip">${esc(n)}</span>`).join('<span>➜</span>')}</div>
      <p>Total distance: <b>${r.distanceKm} km</b></p>`;
  } catch (_) {}
};

load().catch(() => {});
