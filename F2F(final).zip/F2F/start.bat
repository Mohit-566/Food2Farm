@echo off
cd /d "%~dp0backend"
if not exist Food2Farm.cpp (echo Copy your original Food2Farm.cpp into the backend folder first. & pause & exit /b 1)
if not exist httplib.h curl -L -o httplib.h https://raw.githubusercontent.com/yhirose/cpp-httplib/v0.18.3/httplib.h
if not exist json.hpp curl -L -o json.hpp https://github.com/nlohmann/json/releases/download/v3.11.3/json.hpp
if exist Food2Farm.exe del Food2Farm.exe
g++ -std=c++17 -O2 -D_WIN32_WINNT=0x0A00 main.cpp -o Food2Farm.exe -lws2_32 -lwsock32
if not exist Food2Farm.exe (echo Build failed. & pause & exit /b 1)
start http://localhost:8080
Food2Farm.exe
pause
